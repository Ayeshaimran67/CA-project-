`timescale 1ns / 1ps
module Top (
    input  wire        clk,          // 100 MHz board oscillator (W5)
    input  wire        reset,        // BTNC - active HIGH async reset
    input  wire [3:0]  switch_in,    // SW[3:0] - Fibonacci n input (use 1-10)
    output wire [5:0]  led_out,      // LD[5:0] - result in binary
    output wire        led_write_en, // LD15 - pulses on LED register write
    output wire [6:0]  seg,          // 7-segment cathodes
    output wire [3:0]  an,           // 7-segment anodes
    output wire        dp            // Decimal point (always OFF)
);
    wire clk_en;
    ClockDivider u_clkDiv (
        .clk    (clk),
        .reset  (reset),
        .clk_en (clk_en)
    );

    TopLevelProcessor u_proc (
        .clk          (clk),
        .clk_en       (clk_en),
        .reset        (reset),
        .switch_in    (switch_in),
        .led_out      (led_out),
        .led_write_en (led_write_en),
        .seg          (seg),
        .an           (an),
        .dp           (dp)
    );
endmodule