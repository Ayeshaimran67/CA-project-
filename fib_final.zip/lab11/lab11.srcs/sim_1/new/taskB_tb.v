`timescale 1ns / 1ps

module tb_TopLevelProcessor;

    reg        clk;
    reg        clk_en;
    reg        reset;
    reg  [3:0] switch_in;

    wire [5:0] led_out;
    wire       led_write_en;
    wire [6:0] seg;
    wire [3:0] an;
    wire       dp;

    TopLevelProcessor uut (
        .clk          (clk),
        .clk_en       (clk_en),
        .reset        (reset),
        .switch_in    (switch_in),
        .led_out      (led_out),
        .led_write_en (led_write_en),
        .seg          (seg),
        .an           (an),
        .dp           (dp)
    );

    // 100 MHz clock
    initial clk = 0;
    always #5 clk = ~clk;

    // ----------------------------------------------------------------
    // tick(n): fire n CPU enable pulses
    // ----------------------------------------------------------------
    task tick;
        input integer n;
        integer i;
        begin
            for (i = 0; i < n; i = i + 1) begin
                @(posedge clk); #1 clk_en = 1'b1;
                @(posedge clk); #1 clk_en = 1'b0;
            end
        end
    endtask

    // ----------------------------------------------------------------
    // wait_for_led: tick until led_write_en goes HIGH, then tick
    // one more time so led_out is fully registered before we read it
    // ----------------------------------------------------------------
    task wait_for_led;
        input integer max_ticks;
        integer i;
        begin
            i = 0;
            // Wait for led_write_en to go HIGH
            while (!led_write_en && i < max_ticks) begin
                @(posedge clk); #1 clk_en = 1'b1;
                @(posedge clk); #1 clk_en = 1'b0;
                i = i + 1;
            end
            if (i >= max_ticks) begin
                $display("  TIMEOUT after %0d ticks", max_ticks);
            end else begin
                // One extra tick so led_reg latches the new value
                @(posedge clk); #1 clk_en = 1'b1;
                @(posedge clk); #1 clk_en = 1'b0;
            end
        end
    endtask

    // ----------------------------------------------------------------
    // do_reset: hold reset for 12 cycles then release
    // switch_in is NOT touched here - caller sets it before calling
    // ----------------------------------------------------------------
    task do_reset;
        begin
            reset  = 1'b1;
            clk_en = 1'b0;
            repeat(12) @(posedge clk);
            #1 reset = 1'b0;
            @(posedge clk);
        end
    endtask

    // ----------------------------------------------------------------
    // Golden Fibonacci reference
    // ----------------------------------------------------------------
    function [5:0] fib_ref;
        input [3:0] n;
        reg [5:0] a, b, tmp;
        integer   j;
        begin
            a = 6'd0; b = 6'd1;
            if      (n == 0) fib_ref = 6'd0;
            else if (n == 1) fib_ref = 6'd1;
            else begin
                for (j = 2; j <= n; j = j + 1) begin
                    tmp = a + b; a = b; b = tmp;
                end
                fib_ref = b;
            end
        end
    endfunction

    // ----------------------------------------------------------------
    // run_fib_test
    // Each fib(i) in the series needs its own reset cycle because
    // done_flag freezes the PC after every LED write.
    // switch_in = n is always set BEFORE reset releases.
    // ----------------------------------------------------------------
    task run_fib_test_continuous;
        input [3:0] n;
        integer     i;
        begin
            $display("\n--- Running Continuous Fibonacci for n = %0d ---", n);
            
            switch_in = n;
            do_reset; // Reset once at the very beginning

            for (i = 1; i <= n; i = i + 1) begin
                // Wait for the next Fibonacci number to be written to the LED
                wait_for_led(500000); 
                
                $display("  Fib(%0d) = %2d", i, led_out);

                // Give the CPU a few cycles of "breathing room" 
                // before looking for the next write_en
                tick(5); 
            end
        end
    endtask
    // ----------------------------------------------------------------
    // Memory check at startup
    // ----------------------------------------------------------------
    task check_memory;
        integer idx;
        begin
            $display("\n=== Instruction Memory (first 10 words) ===");
            for (idx = 0; idx < 10; idx = idx + 1)
                $display("  mem[%02d] = %08h", idx, uut.u_iMem.memory[idx]);
            $display("  (mem[0] must be 0f400113)");
            $display("===========================================\n");
        end
    endtask

    // ----------------------------------------------------------------
    // Auto-print every LED write event
    // ----------------------------------------------------------------
    always @(posedge clk) begin
        if (led_write_en)
            $display("  [LED WRITE] led_out=%2d  seg=%07b  an=%04b  t=%0t",
                     led_out, seg, an, $time);
    end

    // ----------------------------------------------------------------
    // MAIN
    // ----------------------------------------------------------------
    initial begin
        $dumpfile("tb_fib.vcd");
        $dumpvars(0, tb_TopLevelProcessor);

        clk       = 1'b0;
        clk_en    = 1'b0;
        reset     = 1'b1;
        switch_in = 4'd0;

        repeat(16) @(posedge clk);
        reset = 1'b0;
        @(posedge clk);

        check_memory;

        run_fib_test_continuous(4'd1);   // expect: 1
        run_fib_test_continuous(4'd4);   // expect: 1 1 2 3
        run_fib_test_continuous(4'd6);   // expect: 1 1 2 3 5 8
        run_fib_test_continuous(4'd7);   // expect: 1 1 2 3 5 8 13

        // Edge case: n=0 should never write LED
        $display("\n=== EDGE CASE: n=0 (no LED write expected) ===");
        switch_in = 4'd0;
        do_reset;
        tick(500);
        if (!led_write_en)
            $display("  PASS: no LED write with n=0");
        else
            $display("  FAIL: unexpected LED write with n=0");

        $display("\n============================================================");
        $display("ALL TESTS COMPLETE");
        $display("============================================================");
        $finish;
    end

endmodule