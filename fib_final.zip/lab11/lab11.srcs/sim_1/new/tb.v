`timescale 1ns / 1ps
module tb_fibonacci;

    reg        clk;
    reg        clk_en;
    reg        reset;
    reg  [3:0] switch_in;
    wire [5:0] led_out;
    wire       led_write_en;
    wire [6:0] seg;
    wire [3:0] an;
    wire       dp;

    TopLevelProcessor dut (
        .clk         (clk),
        .clk_en      (clk_en),
        .reset       (reset),
        .switch_in   (switch_in),
        .led_out     (led_out),
        .led_write_en(led_write_en),
        .seg         (seg),
        .an          (an),
        .dp          (dp)
    );

    initial clk = 0;
    always #5 clk = ~clk;

    integer pass_count, fail_count, test_num;
    integer sw_n, pulse_p, found, t;
    reg [5:0] tick_val;
    reg       tick_wen;

    function [5:0] fib_gold;
        input integer n;
        begin
            case (n)
                1:  fib_gold = 6'd1;
                2:  fib_gold = 6'd1;
                3:  fib_gold = 6'd2;
                4:  fib_gold = 6'd3;
                5:  fib_gold = 6'd5;
                6:  fib_gold = 6'd8;
                7:  fib_gold = 6'd13;
                8:  fib_gold = 6'd21;
                9:  fib_gold = 6'd34;
                10: fib_gold = 6'd55;
                default: fib_gold = 6'd0;
            endcase
        end
    endfunction

    task do_reset;
        begin
            reset     = 1;
            clk_en    = 0;
            switch_in = 0;
            repeat(8) @(posedge clk);
            #1;
            reset = 0;
            @(posedge clk); #1;
        end
    endtask

    task one_tick;
        begin
            @(negedge clk);
            clk_en = 1;
            @(posedge clk); #1;
            tick_wen = led_write_en;
            tick_val = led_out;
            clk_en   = 0;
        end
    endtask

    task wait_for_pulse;
        input integer max_t;
        begin
            found = 0;
            t = 0;
            while (t < max_t && !found) begin
                one_tick;
                if (tick_wen) found = 1;
                t = t + 1;
            end
        end
    endtask

    localparam INIT_BUDGET  = 200;
    localparam PULSE_BUDGET = 10000;

    initial begin
        $dumpfile("tb_fibonacci.vcd");
        $dumpvars(0, tb_fibonacci);

        pass_count = 0; fail_count = 0; test_num = 0;

        $display("==========================================================");
        $display("  Fibonacci Sequence Testbench");
        $display("==========================================================");

        sw_n = 1;
        while (sw_n <= 10) begin

            do_reset;
            switch_in = sw_n[3:0];

            $display("----------------------------------------------------------");
            $write("  N=%0d  expected sequence: ", sw_n);
            pulse_p = 1;
            while (pulse_p <= sw_n) begin
                if (pulse_p < sw_n) $write("%0d, ", fib_gold(pulse_p));
                else                $write("%0d",   fib_gold(pulse_p));
                pulse_p = pulse_p + 1;
            end
            $display("");

            // Skip pulse #0 - IDLE clears LED (val=0)
            wait_for_pulse(INIT_BUDGET);
            if (!found) begin
                test_num = test_num + 1;
                $display("  [FAIL] Test %0d: N=%0d - init pulse timeout (%0d ticks)",
                         test_num, sw_n, INIT_BUDGET);
                fail_count = fail_count + 1;
            end else begin

                // Verify every pulse 1..N individually
                // N=4 ? check fib(1)=1, fib(2)=1, fib(3)=2, fib(4)=3
                pulse_p = 1;
                while (pulse_p <= sw_n) begin
                    wait_for_pulse(PULSE_BUDGET);
                    test_num = test_num + 1;
                    if (!found) begin
                        $display("  [FAIL] Test %0d: N=%0d fib(%0d) - pulse timeout (%0d ticks)",
                                 test_num, sw_n, pulse_p, PULSE_BUDGET);
                        fail_count = fail_count + 1;
                        pulse_p = sw_n + 1;
                    end else if (tick_val === fib_gold(pulse_p)) begin
                        $display("  [PASS] Test %0d: N=%0d fib(%0d) = %0d",
                                 test_num, sw_n, pulse_p, tick_val);
                        pass_count = pass_count + 1;
                        pulse_p = pulse_p + 1;
                    end else begin
                        $display("  [FAIL] Test %0d: N=%0d fib(%0d) expected=%0d got=%0d",
                                 test_num, sw_n, pulse_p,
                                 fib_gold(pulse_p), tick_val);
                        fail_count = fail_count + 1;
                        pulse_p = pulse_p + 1;
                    end
                end
            end

            sw_n = sw_n + 1;
        end

        // N=0: stall test
        $display("----------------------------------------------------------");
        do_reset;
        switch_in = 4'd0;
        wait_for_pulse(INIT_BUDGET);
        wait_for_pulse(300);
        test_num = test_num + 1;
        if (!found) begin
            $display("  [PASS] Test %0d: N=0 stalls correctly", test_num);
            pass_count = pass_count + 1;
        end else begin
            $display("  [FAIL] Test %0d: Unexpected pulse with N=0 (val=%0d)",
                     test_num, tick_val);
            fail_count = fail_count + 1;
        end

        // Mid-run reset test
        do_reset;
        switch_in = 4'd4;
        wait_for_pulse(INIT_BUDGET);
        wait_for_pulse(PULSE_BUDGET);
        do_reset;
        #2;
        test_num = test_num + 1;
        if (led_out === 6'd0) begin
            $display("  [PASS] Test %0d: Mid-run reset clears LED", test_num);
            pass_count = pass_count + 1;
        end else begin
            $display("  [FAIL] Test %0d: led_out=%0d after reset (expected 0)",
                     test_num, led_out);
            fail_count = fail_count + 1;
        end

        $display("==========================================================");
        $display("  %0d PASSED   %0d FAILED   (%0d total)",
                 pass_count, fail_count, test_num);
        if (fail_count == 0) $display("  *** ALL TESTS PASSED ***");
        else                 $display("  *** %0d TEST(S) FAILED ***", fail_count);
        $display("==========================================================");
        $finish;
    end

    initial begin
        #2_000_000_000;
        $display("[WATCHDOG] Simulation timed out");
        $finish;
    end

endmodule